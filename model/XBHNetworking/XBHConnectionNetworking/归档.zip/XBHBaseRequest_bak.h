//
//  XBHBaseRequest.h
//  GWMessageSessionSDK
//
//  Created by xubh-note on 15/3/12.
//  Copyright (c) 2015年 xu banghui. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "AFDownloadRequestOperation.h"
#import "XBHNetworking.h"




@interface XBHBaseRequest : NSObject


@property       (nonatomic)     NSInteger       tag;

@property (nonatomic,strong,readonly) NSDictionary *responseHeaders;

@property (nonatomic,readonly) NSInteger responseStatusCode;

@property (nonatomic,strong,readonly) NSData       *responseData;

@property (nonatomic,strong,readonly) NSString     *responseString;

@property (nonatomic, strong, readonly) id responseJSONObject;

@property (nonatomic)          NSTimeInterval   timeout;

@property (nonatomic,strong)    NSDictionary            *requestHeaders;

@property (nonatomic,strong)    AFHTTPRequestOperation   *afOperation;

@property (nonatomic,strong)    NSString    *requestURLString;
//需 是 XBHRequestMethodGet
@property (nonatomic,strong)    NSString    *downloadFileStorePath;

@property (nonatomic,assign)    XBHRequestMethod    requestMethod;

@property (nonatomic,strong)    id                  requestArgument;

@property (nonatomic,strong)    NSDictionary    *userInfo;

@property (nonatomic,assign)    XBHRequestSerializerType   requestSerializerType;

//请求的Server用户名和密码
@property (nonatomic,strong)    NSArray          *requestAuthorizationHeaderFieldArray;

@property (nonatomic, copy) void (^successCompletionBlock)(XBHBaseRequest *);

@property (nonatomic, copy) void (^failureCompletionBlock)(XBHBaseRequest *);

@property (nonatomic,copy)      AFDownloadProgressBlock     downlooadProgressBlock;

@property (nonatomic,copy)      AFConstructingBlock         uploadConstructingBlock;

+(instancetype)requestWithURLString:(NSString *)urlstring;

- (instancetype)initWithURlString:(NSString *)urlString;


/// block回调
- (void)startWithCompletionBlockWithSuccess:(void (^)(XBHBaseRequest *request))success
                                    failure:(void (^)(XBHBaseRequest *request))failure;

- (void)setCompletionBlockWithSuccess:(void (^)(XBHBaseRequest *request))success
                              failure:(void (^)(XBHBaseRequest *request))failure;

/// 把block置nil来打破循环引用
- (void)clearCompeleteBlock;


-(void)stop;

-(BOOL)isExecuting;




/*
 
    子类覆盖 方法
 
 */

/// 是否使用CDN的host地址
- (BOOL)useCDN;

/// 用于检查JSON是否合法的对象
- (id)jsonValidator;

/// 用于检查Status Code是否正常的方法
- (BOOL)statusCodeValidator;



@end
