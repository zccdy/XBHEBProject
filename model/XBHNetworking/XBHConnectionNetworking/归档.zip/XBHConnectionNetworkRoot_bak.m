//
//  XBHConnectionNetworkRoot.m
//  GWMessageSessionSDK
//
//  Created by xubh-note on 15/3/12.
//  Copyright (c) 2015年 xu banghui. All rights reserved.
//

#import "XBHConnectionNetworkRoot.h"
#import "AFNetworking.h"
#import "XBHBaseRequest.h"

@implementation XBHConnectionNetworkRoot{
    AFHTTPRequestOperationManager *_manager;
    NSMutableDictionary *_requestsRecord;
}

+ (XBHConnectionNetworkRoot *)sharedRoot {
    static id sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}


+ (BOOL)checkJson:(id)json withValidator:(id)validatorJson {
    if ([json isKindOfClass:[NSDictionary class]] &&
        [validatorJson isKindOfClass:[NSDictionary class]]) {
        NSDictionary * dict = json;
        NSDictionary * validator = validatorJson;
        BOOL result = YES;
        NSEnumerator * enumerator = [validator keyEnumerator];
        NSString * key;
        while ((key = [enumerator nextObject]) != nil) {
            id value = dict[key];
            id format = validator[key];
            if ([value isKindOfClass:[NSDictionary class]]
                || [value isKindOfClass:[NSArray class]]) {
                return [self checkJson:value withValidator:format];
            } else {
                if ([value isKindOfClass:format] == NO &&
                    [value isKindOfClass:[NSNull class]] == NO) {
                    result = NO;
                    break;
                }
            }
        }
        return result;
    } else if ([json isKindOfClass:[NSArray class]] &&
               [validatorJson isKindOfClass:[NSArray class]]) {
        NSArray * validatorArray = (NSArray *)validatorJson;
        if (validatorArray.count > 0) {
            NSArray * array = json;
            NSDictionary * validator = validatorJson[0];
            for (id item in array) {
                BOOL result = [self checkJson:item withValidator:validator];
                if (!result) {
                    return NO;
                }
            }
        }
        return YES;
    } else if ([json isKindOfClass:validatorJson]) {
        return YES;
    } else {
        return NO;
    }
}

+ (NSString *)urlParametersStringFromParameters:(NSDictionary *)parameters {
    NSMutableString *urlParametersString = [[NSMutableString alloc] initWithString:@""];
    if (parameters && parameters.count > 0) {
        for (NSString *key in parameters) {
            NSString *value = parameters[key];
            value = [NSString stringWithFormat:@"%@",value];
            value = [self urlEncode:value];
            [urlParametersString appendFormat:@"&%@=%@", key, value];
        }
    }
    return urlParametersString;
}

+ (NSString *)urlStringWithOriginUrlString:(NSString *)originUrlString appendParameters:(NSDictionary *)parameters {
    NSString *filteredUrl = originUrlString;
    NSString *paraUrlString = [self urlParametersStringFromParameters:parameters];
    if (paraUrlString && paraUrlString.length > 0) {
        if ([originUrlString rangeOfString:@"?"].location != NSNotFound) {
            filteredUrl = [filteredUrl stringByAppendingString:paraUrlString];
        } else {
            filteredUrl = [filteredUrl stringByAppendingFormat:@"?%@", [paraUrlString substringFromIndex:1]];
        }
        return filteredUrl;
    } else {
        return originUrlString;
    }
}


+ (NSString*)urlEncode:(NSString*)str {
    //different library use slightly different escaped and unescaped set.
    //below is copied from AFNetworking but still escaped [] as AF leave them for Rails array parameter which we don't use.
    //https://github.com/AFNetworking/AFNetworking/pull/555
    NSString *result = (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (__bridge CFStringRef)str, CFSTR("."), CFSTR(":/?#[]@!$&'()*+,;="), kCFStringEncodingUTF8);
    return result;
}

+ (void)addDoNotBackupAttribute:(NSString *)path {
    NSURL *url = [NSURL fileURLWithPath:path];
    NSError *error = nil;
    [url setResourceValue:[NSNumber numberWithBool:YES] forKey:NSURLIsExcludedFromBackupKey error:&error];
}


+ (NSString *)appVersionString {
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}



- (void)dealloc
{
    [_manager.operationQueue cancelAllOperations];
}
- (id)init {
    self = [super init];
    if (self) {
        _manager = [AFHTTPRequestOperationManager manager];
       // _manager.requestSerializer=nil;//每个请求的header 和method 单独设置
        _manager.responseSerializer=[AFHTTPResponseSerializer serializer];
        _manager.operationQueue.maxConcurrentOperationCount = 4;
        _requestsRecord = [NSMutableDictionary dictionary];
       
    }
    return self;
}


- (void)addRequest:(XBHBaseRequest *)request {
    
    id param = request.requestArgument;
    AFConstructingBlock constructingBlock =request.uploadConstructingBlock;
    
    if (request.requestSerializerType == XBHRequestSerializerTypeHTTP) {
        _manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    } else if (request.requestSerializerType == XBHRequestSerializerTypeJSON) {
        _manager.requestSerializer = [AFJSONRequestSerializer serializer];
    }
    
    _manager.requestSerializer.timeoutInterval =request.timeout;
    
    // if api need server username and password
    NSArray *authorizationHeaderFieldArray = [request requestAuthorizationHeaderFieldArray];
    if (authorizationHeaderFieldArray != nil) {
        [_manager.requestSerializer setAuthorizationHeaderFieldWithUsername:(NSString *)authorizationHeaderFieldArray.firstObject
                                                                   password:(NSString *)authorizationHeaderFieldArray.lastObject];
    }
    
    // if api need add custom value to HTTPHeaderField
    NSDictionary *headerFieldValueDictionary = request.requestHeaders;
    if (headerFieldValueDictionary != nil) {
        for (id httpHeaderField in headerFieldValueDictionary.allKeys) {
            id value = headerFieldValueDictionary[httpHeaderField];
            if ([httpHeaderField isKindOfClass:[NSString class]] && [value isKindOfClass:[NSString class]]) {
                [_manager.requestSerializer setValue:(NSString *)value forHTTPHeaderField:(NSString *)httpHeaderField];
            }
        }
    }
    
    
    if (request.requestMethod == XBHRequestMethodGet) {
        if (request.downloadFileStorePath) {
            // add parameters to URL;
            NSString *filteredUrl = [XBHConnectionNetworkRoot urlStringWithOriginUrlString:request.requestURLString appendParameters:param];
            
            NSURLRequest *requestUrl = [NSURLRequest requestWithURL:[NSURL URLWithString:filteredUrl]];
            AFDownloadRequestOperation *operation = [[AFDownloadRequestOperation alloc] initWithRequest:requestUrl
                                                                                             targetPath:request.downloadFileStorePath shouldResume:YES];
            [operation setProgressiveDownloadProgressBlock:request.downlooadProgressBlock];
            [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                [self handleRequestResult:operation];
            }                                failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [self handleRequestResult:operation];
            }];
            request.afOperation = operation;
            [_manager.operationQueue addOperation:operation];
        } else {
            request.afOperation = [_manager GET:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
                [self handleRequestResult:operation];
            }                                failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [self handleRequestResult:operation];
            }];
        }
    } else if (request.requestMethod  == XBHRequestMethodPost) {
        if (constructingBlock != nil) {
            request.afOperation = [_manager POST:request.requestURLString parameters:param constructingBodyWithBlock:constructingBlock
                                              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                                                  [self handleRequestResult:operation];
                                              } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                                                  [self handleRequestResult:operation];
                                              }];
        } else {
            request.afOperation = [_manager POST:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
                [self handleRequestResult:operation];
            }                                 failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                [self handleRequestResult:operation];
            }];
        }
    } else if (request.requestMethod  == XBHRequestMethodHead) {
        request.afOperation = [_manager HEAD:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation) {
            [self handleRequestResult:operation];
        }                                 failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [self handleRequestResult:operation];
        }];
    } else if (request.requestMethod  == XBHRequestMethodPut) {
        request.afOperation = [_manager PUT:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [self handleRequestResult:operation];
        }                                failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [self handleRequestResult:operation];
        }];
    } else if (request.requestMethod  == XBHRequestMethodDelete) {
        request.afOperation = [_manager DELETE:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [self handleRequestResult:operation];
        }                                   failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [self handleRequestResult:operation];
        }];
    } else if (request.requestMethod  == XBHRequestMethodPatch) {
        request.afOperation = [_manager PATCH:request.requestURLString parameters:param success:^(AFHTTPRequestOperation *operation, id responseObject) {
            [self handleRequestResult:operation];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            [self handleRequestResult:operation];
        }];
    }
    
    [self addOperation:request];
}

- (void)cancelRequest:(XBHBaseRequest *)request {
    [request.afOperation cancel];
    [request clearCompeleteBlock];
    [self removeOperation:request.afOperation];
   
    
}

- (void)cancelAllRequest {
    NSDictionary *copyRecord = [_requestsRecord copy];
    for (NSString *key in copyRecord) {
        XBHBaseRequest *request = copyRecord[key];
        [request stop];
    }
    [_manager.operationQueue cancelAllOperations];
}

- (BOOL)checkResult:(XBHBaseRequest *)request {
    BOOL result = [request statusCodeValidator];
    if (!result) {
        return result;
    }
    id validator = [request jsonValidator];
    if (validator != nil) {
        id json = [request responseJSONObject];
        result = [XBHConnectionNetworkRoot checkJson:json withValidator:validator];
    }
    return result;
}

- (void)handleRequestResult:(AFHTTPRequestOperation *)operation {
    NSString *key = [self requestHashKey:operation];
    XBHBaseRequest *request = _requestsRecord[key];
    if (request) {
        BOOL succeed = [self checkResult:request];
        if (succeed) {
           
            if (request.successCompletionBlock) {
                request.successCompletionBlock(request);
            }
            
        } else {
            if (request.failureCompletionBlock) {
                request.failureCompletionBlock(request);
            }
        }
    }
    [self removeOperation:operation];
    [request clearCompeleteBlock];
}

- (NSString *)requestHashKey:(AFHTTPRequestOperation *)operation {
    NSString *key = [NSString stringWithFormat:@"%lu", (unsigned long)[operation hash]];
    return key;
}

- (void)addOperation:(XBHBaseRequest *)request {
    if (request.afOperation != nil) {
        NSString *key = [self requestHashKey:request.afOperation];
        _requestsRecord[key] = request;
    }
    
}

- (void)removeOperation:(AFHTTPRequestOperation *)operation {
    NSString *key = [self requestHashKey:operation];
    [_requestsRecord removeObjectForKey:key];
}



-(void)suspend{
    if (!_manager.operationQueue.suspended) {
         _manager.operationQueue.suspended=YES;
    }
}

-(void)resume{
    if (_manager.operationQueue.suspended) {
        _manager.operationQueue.suspended=NO;
    }

}


@end
