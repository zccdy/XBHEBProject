//
//  XBHBaseRequest.m
//  GWMessageSessionSDK
//
//  Created by xubh-note on 15/3/12.
//  Copyright (c) 2015年 xu banghui. All rights reserved.
//

#import "XBHBaseRequest.h"
#import "XBHConnectionNetworkRoot.h"
@interface XBHBaseRequest ()

@end


@implementation XBHBaseRequest
@synthesize tag;
@synthesize responseHeaders;
@synthesize responseStatusCode;
@synthesize responseData;
@synthesize responseString;
@synthesize requestURLString=_requestURLString;
@synthesize afOperation=_afOperation;
@synthesize requestMethod=_requestMethod;
@synthesize timeout;
@synthesize userInfo=_userInfo;

-(NSDictionary *)responseHeaders{
    if (!self.afOperation) {return nil;}
    return self.afOperation.response.allHeaderFields;
}
-(NSData *)responseData{
    if (!self.afOperation) {return nil;}
    return self.afOperation.responseData;
}
-(NSString *)responseString{
    if (!self.afOperation) {return nil;}
    return self.afOperation.responseString;

}
-(NSInteger)responseStatusCode{
    if (!self.afOperation) {return 0;}
    return self.afOperation.response.statusCode;
}
- (id)responseJSONObject {
    if (!self.afOperation) {return nil;}
    return self.afOperation.responseObject;
}


- (void)dealloc
{
    [self stop];
}

+(instancetype)requestWithURLString:(NSString *)urlstring{

    return  [[[self class] alloc] initWithURlString:urlstring];
}

- (instancetype)init
{
  
    return [self initWithURlString:nil];
}
- (instancetype)initWithURlString:(NSString *)urlString
{
    self = [super init];
    if (self) {
        self.requestURLString=urlString;
        self.requestMethod=XBHRequestMethodGet;
        self.requestSerializerType=XBHRequestSerializerTypeHTTP;
        timeout=60.0;
    }
    return self;
}



-(void)start {
    [[XBHConnectionNetworkRoot sharedRoot] addRequest:self];
}

-(void)stop{
    [self clearCompeleteBlock];
    [[XBHConnectionNetworkRoot sharedRoot] cancelRequest:self];

}


- (void)startWithCompletionBlockWithSuccess:(void (^)(XBHBaseRequest *request))success
                                    failure:(void (^)(XBHBaseRequest *request))failure {
    [self setCompletionBlockWithSuccess:success failure:failure];
    [self start];
}


- (void)setCompletionBlockWithSuccess:(void (^)(XBHBaseRequest *request))success
                              failure:(void (^)(XBHBaseRequest *request))failure {
    self.successCompletionBlock = success;
    self.failureCompletionBlock = failure;
}


-(void)clearCompeleteBlock{
    self.successCompletionBlock=nil;
    self.failureCompletionBlock=nil;
}

-(BOOL)isExecuting{
    return self.afOperation.isExecuting;

}




- (BOOL)useCDN {
    return NO;
}

- (id)jsonValidator {
    return nil;
}

- (BOOL)statusCodeValidator {
    NSInteger statusCode = [self responseStatusCode];
    if (statusCode >= 200 && statusCode <=299) {
        return YES;
    } else {
        return NO;
    }
}




@end
