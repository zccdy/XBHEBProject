//
//  XBHConnectionNetworkRoot.h
//  GWMessageSessionSDK
//
//  Created by xubh-note on 15/3/12.
//  Copyright (c) 2015年 xu banghui. All rights reserved.
//

#import <Foundation/Foundation.h>

@class XBHBaseRequest;


@interface XBHConnectionNetworkRoot : NSObject

+ (XBHConnectionNetworkRoot *)sharedRoot;


-(void)addRequest:(XBHBaseRequest *)request;
-(void)cancelRequest:(XBHBaseRequest *)request;
-(void)cancelAllRequest;
-(void)suspend;
-(void)resume;

@end
